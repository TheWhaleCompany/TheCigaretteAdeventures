//: [Next](@next)

import SwiftUI
import PlaygroundSupport
import AVFoundation
import UIKit

struct Scene1: View {
    
    @State private var showStartButton: Bool = true
    @State private var showCigarette: Bool = false
    @State private var showText: Bool = false
    @State private var showChoices: Bool = false
    @State private var gameOver: Bool = false
    @State private var showBackGround: Bool = true
    @State private var moveOn: Bool = false
    
 

    ///////////////////////////////////////////////////////////  CIGARETTE /////////////////////////////////////////////////////////////
    var cigarette: some View {
        Image(named: "Cigarette.png")
            .resizable()
            .frame(width: 200, height: 300)
    }
    /////////////////////////////////////////////////////// TEXT ////////////////////////////////////////
    var narrativeText: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25, style: .circular)
                .fill(Color.white)
            Text("Once upon a time there was a cigarette looking for a purpose in life")
                .font(.headline)
                .italic()
                .padding()
        }
        .frame(width: 350, height: 100)
        .offset(x: 120, y: -100)
    }
    ///////////////////////////////////////////// GAME OVER ///////////////////////////////////////////////////
    var GameOver: some View {
        LinearGradient(colors: [.red, .orange, .yellow], startPoint: .top, endPoint: .bottom)
            .mask(
                Text("GAME OVER")
                    .font(Font.custom("FIRESTARTER", size: 80))
            )
            .frame(height: 80)
            .offset(x: -5, y: -110)
    }
    ///////////////////////////////////////////////////////////  CHOICES  /////////////////////////////////////////////////////////////
    var choices: some View {
        ZStack {
            Image(named: "Choices.png")
                .resizable()
                .frame(width: 304, height: 163)
            VStack(spacing: 27) {
                Button("Go find purpose", action: nextScene)
                    .foregroundColor(.blue)
                    .font(.system(size: 21, weight: .black, design: .serif))
                    .padding(.top, 11)
                Button(action: gameIsOver) {
                    VStack {
                        Text("Remain")
                        Text("Purposeless")
                    }
                }
                .foregroundColor(.black)
                .font(.system(size: 20, weight: .black, design: .serif))
                .padding(.top, 10)
            }
        }
        .offset(x: -5, y: -110)
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    var body: some View {
        ZStack {
            Color.black
                .frame(width: 600, height: 400)
            if showBackGround {
                Image(named: "Background1.png")
                    .resizable()
                    .frame(width: 600, height: 400, alignment: .center)
            }
            ///////////////////////////////////////////////////////////  START BUTTON /////////////////////////////////////////////////////////////
            if showStartButton {
                Button("START STORY", action: launchScene)
                    .font(.system(size: 28, weight: .black, design: .serif))
                    .foregroundColor(.black)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(20)
            }
            ///////////////////////////////////////////////////////////  BACKGROUND  /////////////////////////////////////////////////////////////
            if showCigarette {
                cigarette
                    .offset(x: moveOn ? 350 : -100 , y: 90)
                    .transition(.slide)
                    .rotationEffect(gameOver ? .degrees(90) : .zero, anchor: .bottomLeading)
                    .onAppear {
                        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { _ in
                            withAnimation {
                                showText.toggle()
                            }
                        }
                    }
            }
            if showText {
                narrativeText
                    .transition(.opacity)
                    .onAppear {
                        Timer.scheduledTimer(withTimeInterval: 4, repeats: false) { _ in
                            withAnimation {
                                showText.toggle()
                                showChoices.toggle()
                            }
                        }
                    }
            }
            if showChoices {
                choices
                    .transition(.opacity)
            }
            if gameOver {
                GameOver
                    .transition(.opacity)
                    .onAppear {
                        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { _ in
                            withAnimation {
                                gameOver.toggle()
                                showStartButton.toggle()
                                showCigarette.toggle()
                                showChoices = false
                            }
                        }
                    }
            }
        }
    }
    /////////////////////////////////////////////////////   FUNCTIONS ////////////////////////////////////////////////////////////////////////////////////////
    func launchScene() {
        getFont("FIRESTARTER", "TTF")
        withAnimation(.easeInOut(duration: 2)) {
            showCigarette.toggle()
        }
        showStartButton = false
    }
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    func textAppears() {
        withAnimation(.easeIn(duration: 5)) {
            showText.toggle()
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    func choicesAppear() {
        withAnimation(.easeIn(duration: 5)) {
            showChoices.toggle()
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    func nextScene() {
        withAnimation(.easeOut(duration: 3)) {
            moveOn.toggle()
        }
        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { _ in
            withAnimation {
                showBackGround = false
                showChoices = false
            }
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    func gameIsOver() {
        showChoices.toggle()
        withAnimation {
            gameOver.toggle()
            playSound("GameOver.mp3")
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    func getFont(_ resource: String, _ fontExtension: String) {
        let cfurl = Bundle.main.url(forResource: resource, withExtension: fontExtension)! as CFURL
        CTFontManagerRegisterFontsForURL(cfurl, CTFontManagerScope.process, nil)
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

PlaygroundPage.current.setLiveView(Scene1())
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
extension Image {
    init(named: String) {
        self.init(uiImage: UIImage(named: named)!)
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


