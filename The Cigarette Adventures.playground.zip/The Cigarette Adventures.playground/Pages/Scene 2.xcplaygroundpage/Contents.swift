//: [Previous](@previous)
//: [Next](@next)

import SwiftUI
import PlaygroundSupport

extension Image {
    init(named: String) {
        self.init(uiImage: UIImage(named: named)!)
    }
}

struct Scene2: View {
    
    @State private var showStartButton: Bool = true
    @State private var showCigarette: Bool = false
    @State private var showDeath: Bool = false
    @State private var showDeathBubble: Bool = false
    @State private var showDeathBubble2: Bool = false
    @State private var showCigaretteBubble: Bool = false
    @State private var showChoiceSign: Bool = false
    @State private var willFindFire: Bool = false
    @State private var showGameOver: Bool = false
    @State private var showBackground: Bool = true
    
    
    
    
    //CIGARETTE//
    var cigarette: some View {
        Image(uiImage: UIImage(named: "CigaretteHappy.png")!)
            .resizable()
            .frame(width: 100, height: 200)
            .offset(x: -180, y: 100)
    }
    //DEATH///
    var death: some View {
        Image(uiImage: UIImage(named: "Death.png")!)
            .resizable()
            .frame(width: 250, height: 250)
            .offset(x: 160, y: 85)
            .opacity(2)
    }
    
    //DEATHBUBBLE1//
    var deathBubble1: some View {
        Image(uiImage: UIImage(named: "deathBubble1.png")!)
            .resizable()
            .frame(width: 200, height: 200)
            .offset(x: 100, y: -60)
            .opacity(2)
    }
    
    //DEATHBUBBLE2//
    var deathBubble2: some View {
        Image(uiImage: UIImage(named: "deathBubble2.png")!)
            .resizable()
            .frame(width: 200, height: 200)
            .offset(x: 100, y: -60)
            .opacity(2)
    }
    
    //CIGARBUBBLE1//
    var cigaretteBubble: some View {
        Image(uiImage: UIImage(named: "cigaretteBubble.png")!)
            .resizable()
            .frame(width: 200, height: 200)
            .offset(x: -60, y: 20)
            .opacity(2)
    }
    
    //var choicesSign: some View {
    //Image(uiImage: UIImage(named: "Choices.png")!)
    // .resizable()
    // .frame(width: 304, height: 163)
    //  .offset(x: -10, y: -50)
    //  .opacity(2)
    // }
    
    //GAMEOVER//
    var GameOver: some View {
        LinearGradient(colors: [.red, .orange, .yellow], startPoint: .top, endPoint: .bottom)
            .mask(
                Text("GAME OVER")
                    .font(Font.custom("FIRESTARTER", size: 80))
            )
            .frame(height: 80)
            .offset(x: -5, y: -110)
    }
    
    
    
    var body: some View {
        //        VStack {
        //            //START BUTTON//
        //            Button(action: {
        //                launchScene()
        //            })  {
        //                if showStartButton {
        //                    Text("WALK")
        //                        .fontWeight(.bold)
        //                        .font(.headline)
        //                        .padding()
        //                        .background(Color.blue)
        //                        .cornerRadius(15)
        //                        .foregroundColor(.white)
        //                }
        //            }
        ZStack {
            
            //BACKGROUND//
            Color.black
                .frame(width: 600, height: 400)
                .onAppear {
                    launchScene()
                }
            if showBackground {
                Image(uiImage:  UIImage(named: "Background2.png")!)
                    .resizable()
                    .frame(width: 600, height: 400, alignment: .center)
            }
            
            /////////////////////////////////////////////
            //                if showCigarette {
            cigarette
                .offset(x: showCigarette ? willFindFire ? 1000 : 0 : -200, y: 0)
                .onAppear {
                    Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { _ in
                        withAnimation {
                            showDeath.toggle()
                        }
                    }
                }
            //                }
            if showDeath {
                death
                    .transition(.opacity)
                    .onAppear {
                        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                            withAnimation {
                                showDeathBubble.toggle()
                            }
                        }
                    }
            }
            if showDeathBubble {
                deathBubble1
                    .transition(.opacity)
                    .onAppear {
                        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { _ in
                            withAnimation {
                                showCigaretteBubble.toggle()
                                showDeathBubble.toggle()
                            }
                        }
                    }
                
            }
            if showCigaretteBubble {
                cigaretteBubble
                    .transition(.opacity)
                    .onAppear {
                        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { _ in
                            withAnimation {
                                showCigaretteBubble.toggle()
                                showDeathBubble2.toggle()
                            }
                        }
                    }
                
            }
            if showDeathBubble2 {
                deathBubble2
                    .transition(.opacity)
                    .onAppear {
                        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { _ in
                            withAnimation {
                                showDeathBubble2.toggle()
                                showChoiceSign.toggle()
                            }
                        }
                    }
                
            }
            
            if showChoiceSign{
                sign
                    .transition(.opacity)
                
            }
            
            if showGameOver {
                GameOver
                    .transition(.opacity)
                    .onAppear {
                        //Timer.scheduledTimer(withTimeInterval: 100, repeats: false) { _ in
                        //withAnimation {
                        // showGameOver.toggle()
                        //showStartButton.toggle()
                        //showCigarette.toggle()
                        
                        
                        // }
                        // }
                    }
            }
            
        }
    }
    
    ////////////////////////////////////////////////////////////////////////////
    var sign: some View {
        ZStack {
            Image(named: "Choices.png")
                .resizable()
                .frame(width: 304, height: 163)
            
            VStack(spacing: 38) {
                Button("Go find fire", action: launchScene3)
                    .font(.system(size:28, weight: .black, design: .serif))
                
                Button("Ignore him", action: gameOver)
                
                    .foregroundColor(.black)
                    .padding(.top, 5)
            }
            .font(.system(size: 24, weight: .black, design: .serif))
            .padding(.top, 5)
        }
        .offset(x: -5, y: -110)
        
    }
    
    /* var blackScreen: some View {
     ZStack {
     Image(named: "blackScreen.png")
     .resizable()
     .frame(width: 600, height: 400)
     }
     }*/
    
    
    
    //////////////////////////////////////////////////////////////////////////
    
    
    
    func launchScene3()
    {
        showDeath.toggle()
        //        cigaretteArrives2()
        withAnimation (.easeInOut(duration: 5))  {
            willFindFire.toggle()
            Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { _ in
                withAnimation {
                    showBackground.toggle()
                    showChoiceSign.toggle()
                }
            }
            
            
            
        }
        
        
        
    }
    
    
    
    //FUNCTIONS//
    func launchScene() {
        getFont("FIRESTARTER", "TTF")
        cigaretteArrives()
        showStartButton.toggle()
    }
    
    ///////////////////////////////////////
    func cigaretteArrives() {
        withAnimation(.easeInOut(duration: 2)) {
            showCigarette.toggle()
        }
    }
    
    func cigaretteArrives2() {
        withAnimation(.easeInOut(duration: 5)) {
            showDeath.toggle()
        }
    }
    
    /////////////////////////////////////
    func deathAppears() {
        withAnimation(.easeIn(duration: 1)) {
            showDeath.toggle()
        }
    }
    
    /////////////////////////////////////
    func bubbleAppears() {
        withAnimation(.easeIn(duration: 1)) {
            showDeathBubble.toggle()
        }
    }
    
    //////////////////////////////////////
    func bubbleAppears1() {
        withAnimation(.easeIn(duration: 1)) {
            showDeathBubble.toggle()
        }
    }
    
    //////////////////////////////////////
    func bubbleAppears2() {
        withAnimation(.easeIn(duration: 1)) {
            showDeathBubble.toggle()
        }
    }
    
    func choiceSignAppears() {
        withAnimation(.easeIn(duration:1)){
            showChoiceSign.toggle()
        }
    }
    
    func gameOver() {
        showChoiceSign.toggle()
        withAnimation {
            showGameOver.toggle()
            playSound("GameOver.mp3")
        }
    }
    
    func getFont(_ resource: String, _ fontExtension: String) {
        let cfurl = Bundle.main.url(forResource: resource, withExtension: fontExtension)! as CFURL
        CTFontManagerRegisterFontsForURL(cfurl, CTFontManagerScope.process, nil)
    }
    
    
    
    
    ////////////////////////////////////
}
PlaygroundPage.current.setLiveView(Scene2())
