//: [Previous](@previous)
//: [Next](@next)

import AVFoundation
import SwiftUI
import UIKit
import PlaygroundSupport

public extension Image {
    init(named: String) {
        self.init(uiImage: UIImage(named: named)!)
    }
}

struct Scene3: View {
    @State private var showCigarette = false
    @State private var showSign = false
    @State private var isTouchingFire = false
    @State private var hasTouchedFire = false
    @State private var isOnFire = false
    @State private var signScale: CGFloat = 1
    @State private var showDeath = false
    @State private var showView = true
    
    func startView() {
        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
            withAnimation(.easeInOut(duration: 1)) {
                showCigarette.toggle()
            }
        }
        
        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { _ in
            showSign.toggle()
        }
    }
    
    func touchFire() {
        showSign.toggle()
        isTouchingFire.toggle()
        
        Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { _ in
            isTouchingFire.toggle()
        }
        
        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
            withAnimation(.easeInOut(duration: 0.5)) {
                hasTouchedFire.toggle()
            }
            
            Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { _ in
                isOnFire.toggle()
                playSound("CigaretteScream.mp3")
                
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false) { _ in
                    withAnimation(.easeInOut(duration: 0.5)) {
                        showCigarette.toggle()
                    }
                    
                    Timer.scheduledTimer(withTimeInterval: 1.5, repeats: false) { _ in
                        withAnimation(.easeInOut(duration: 1)) {
                            showDeath.toggle()
                            playSound("DeathLaugh.mp3")
                        }
                        
                        Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { _ in
                            withAnimation(.easeInOut(duration: 1)) {
                                showDeath.toggle()
                            }
                            
                            Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { _ in
                                withAnimation(.easeInOut(duration: 2)) {
                                    showView.toggle()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    var cigarette: some View {
        Image(named: isOnFire ? "CigaretteScreaming.png" : "CigaretteHappy.png")
            .resizable()
            .overlay(Text(hasTouchedFire ? "🔥" : "")
                        .font(.system(size: 70))
                        .offset(x: -5, y: -110))
            .frame(width: 100, height: 250)
            .offset(x: showCigarette ? isTouchingFire ? -110 : -200 : -350,
                    y: showCigarette ? isTouchingFire ? 165 : 75 : -50)
            .rotationEffect(isTouchingFire ? .degrees(90) : .zero, anchor: .bottomLeading)
            .animation(.easeInOut(duration: 1), value: isTouchingFire)
    }
    
    var death: some View {
        Image(named: "Death.png")
            .resizable()
            .frame(width: 175, height: 175)
            .offset(x: 150, y: -25)
            .opacity(showDeath ? 1 : 0)
    }
    
    var sign: some View {
        ZStack {
            Image(named: "Choices.png")
                .resizable()
                .frame(width: 304, height: 163)
            
            VStack(spacing: 38) {
                Button("Touch the fire", role: .destructive, action: touchFire)
                    .font(.system(size: 26, weight: .black, design: .serif))
                
                Button("Go back") {
                    withAnimation {
                        signScale *= 1.1
                    }
                }
                .font(.system(size: 28, weight: .black, design: .serif))
                .foregroundColor(.black)
                .padding(.top, 3)
            }
            .padding(.top, 5)
        }
        .offset(x: -5, y: -70/signScale)
        .scaleEffect(signScale)
        .opacity(showSign ? 1 : 0)
    }
    
    var body: some View {
        ZStack {
            Image(named: "Background3.png")
                .resizable()
                .frame(width: 600, height: 400)
                .onAppear { startView() }
            
            cigarette
            
            death
            
            sign
            
            Color.black
                .opacity(showView ? 0 : 1)
        }
    }
}

PlaygroundPage.current.setLiveView(Scene3())
