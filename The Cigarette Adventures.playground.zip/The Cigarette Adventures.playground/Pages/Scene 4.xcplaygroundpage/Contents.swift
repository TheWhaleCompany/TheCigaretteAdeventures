//: [Previous](@previous)
//: [Next](@next)

import PlaygroundSupport
import SwiftUI

// MARK: - The Cigarette Adventures, page 4

struct Scene4: View {
    private let loopAnimationDuration: Double = 2
    private let totalAnimationDuration = 6
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    @State var degrees : Double = 0
    @State var animationCountdown = 0
    @State var isAnimating = false
    @State var cigaretteIsDead = false
    
    var body: some View {
        ZStack {
            Background
            CigaretteRunning
            if cigaretteIsDead {
                CigaretteDead
                GameOver
            }
        }
        .onAppear {
            getFont("FIRESTARTER", "TTF")
            startAnimation
        }
        .onReceive(timer) { _ in animatedScene }
    }
}

extension Scene4 {
    
    // MARK: - Views
    var Background: some View {
        getImage("Background4")
            .resizable()
            .frame(width: 600, height: 400)
    }
    var CigaretteRunning: some View {
        getImage("CigaretteRunning")
            .resizable()
            .frame(width: 300, height: 250)
            .offset(x: isAnimating ? 700 : -700, y: 110)
            .rotation3DEffect(.degrees(degrees), axis: (x: 0, y: 1, z: 0))
    }
    var CigaretteDead: some View {
        getImage("CigaretteDead")
            .resizable()
            .frame(width: 300, height: 250)
            .offset(x: 0, y: 130)
            .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
    }
    var GameOver: some View {
        LinearGradient(colors: [.red, .orange, .yellow], startPoint: .top, endPoint: .bottom)
            .mask(
                Text("GAME OVER")
                    .font(Font.custom("FIRESTARTER", size: 80))
            )
            .frame(height: 80)
         
    }
    
    // MARK: - Logic
    
    // Allows to show imported images from "Resources" folder.
    func getImage(_ imageString: String) -> Image {
        guard let image = UIImage(named: imageString) else { return Image(systemName: "multiply.circle") }
        return Image(uiImage: image)
    }
    // When called, allows to use imported custom fonts from "Resources" folder.
    func getFont(_ resource: String, _ fontExtension: String) {
        let cfurl = Bundle.main.url(forResource: resource, withExtension: fontExtension)! as CFURL
        CTFontManagerRegisterFontsForURL(cfurl, CTFontManagerScope.process, nil)
    }
    var startAnimation: Void {
        withAnimation(.linear(duration: loopAnimationDuration).repeatForever(autoreverses: false)) {
            isAnimating.toggle()
            Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { _ in
                playSound("Scream.mp3")
            }
            Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false) { _ in
                playSound("Scream.mp3")
            }
            Timer.scheduledTimer(withTimeInterval: 4.5, repeats: false) { _ in
                playSound("Scream.mp3")
            }
        }
    }
    var animatedScene: Void {
        if animationCountdown < totalAnimationDuration {
            animationCountdown += 1
            switchCigaretteDirection
            
        } else {
            endAnimation
        }
    }
    var switchCigaretteDirection: Void {
        if animationCountdown % Int(loopAnimationDuration) == 0 {
            degrees = degrees == 0 ? 180 : 0
        }
    }
    var killCigarette: Void {
        withAnimation(.linear(duration: loopAnimationDuration)) {
            cigaretteIsDead.toggle()
            playSound("GameOver.mp3")
        }
        isAnimating.toggle()
    }
    var cancelAnimation: Void {
        timer.upstream.connect().cancel()
    }
    var endAnimation: Void {
        killCigarette
        cancelAnimation
    }
}

// Allows to show the preview of a view.
PlaygroundPage.current.setLiveView(Scene4())
