import AVFoundation
import Foundation

var player: AVAudioPlayer!

public func playSound(_ fileName: String) {
    guard let soundFileURL = Bundle.main.url(forResource: fileName, withExtension: nil) else { return }
    
    do {
        player = try AVAudioPlayer(contentsOf: soundFileURL)
        player.play()
    } catch { }
}
